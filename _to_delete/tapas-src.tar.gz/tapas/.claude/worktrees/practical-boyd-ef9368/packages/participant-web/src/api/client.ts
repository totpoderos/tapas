/**
 * The participant app's typed door to the backend API. Requests go same-origin
 * by default (a dev/preview proxy forwards `/contests` to the API), so the voter
 * cookie is first-party and `credentials: 'include'` carries it — the token is
 * never in JS. Set `VITE_API_BASE_URL` to talk to a different origin.
 */
const API_BASE = import.meta.env.VITE_API_BASE_URL ?? '';

/** A failed API call — carries the HTTP status and the API's error code when present. */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code?: string,
    message?: string,
  ) {
    super(message ?? `Request failed (${status})`);
    this.name = 'ApiError';
  }
}

async function send(path: string, method: 'GET' | 'POST', body?: unknown): Promise<Response> {
  return fetch(`${API_BASE}${path}`, {
    method,
    credentials: 'include',
    headers: body !== undefined ? { 'content-type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

async function errorFrom(response: Response): Promise<ApiError> {
  const parsed = (await response.json().catch(() => undefined)) as
    | { error?: { code?: string; message?: string } }
    | undefined;
  return new ApiError(response.status, parsed?.error?.code, parsed?.error?.message);
}

/**
 * True when the host has deleted the contest out from under this participant.
 *
 * The API answers `410 Gone` rather than `404` on the voter-scoped routes: a
 * voter token proves prior association with that contest, so naming it reveals
 * nothing they did not already know. It lets the app say "this is gone" instead
 * of showing a generic failure or spinning forever.
 */
export function isContestDeleted(caught: unknown): boolean {
  return caught instanceof ApiError && caught.status === 410;
}

/**
 * True when the request was refused because the participant is no longer signed
 * in — their session expired, or the browser never kept it.
 *
 * Worth telling apart from any other failure: retrying cannot fix it, so
 * offering "please try again" wastes the participant's time at the one moment
 * they are standing in a room holding a plate. They need the way back to joining.
 */
export function isSignedOut(caught: unknown): boolean {
  return caught instanceof ApiError && caught.status === 401;
}

/**
 * One place on a contest's roster. `taken` is the whole of what is said about
 * somebody who has already arrived — not when they did, not anything else.
 */
export interface Place {
  readonly participantId: string;
  readonly displayName: string;
  readonly taken: boolean;
}

/** A contest's roster as a joiner sees it: every place, open and taken alike. */
export interface Roster {
  readonly contestId: string;
  readonly places: readonly Place[];
}

/** Who a joined participant is, on a contest. */
export interface Identity {
  readonly participantId: string;
  readonly contestId: string;
  readonly displayName: string;
}

/** Looks up a contest's whole roster by join code; throws ApiError (404 when the code is unknown). */
export async function getPlaces(joinCode: string): Promise<Roster> {
  const response = await send(`/contests/${encodeURIComponent(joinCode)}/places`, 'GET');
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Roster;
}

/** Claims a place by the join code, becoming that participant; throws ApiError (409 when taken). */
export async function claimPlace(joinCode: string, participantId: string): Promise<Identity> {
  const response = await send(`/contests/${encodeURIComponent(joinCode)}/claim`, 'POST', { participantId });
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Identity;
}

/** The participant this device is remembered as on the given contest, or null if not recognised. */
export async function getMe(contestId: string): Promise<Identity | null> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/me`, 'GET');
  if (response.status === 401) return null;
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Identity;
}

/** A dish a cook has submitted. `submitterIds` says whose it is (a couple may share one). */
export interface Dish {
  readonly dishId: string;
  readonly name: string;
  readonly description: string | null;
  readonly submitterIds: readonly string[];
}

/**
 * The dishes submitted so far, and how many the contest is waiting for — one per
 * place on the roster. `expected` is a count and only a count: who has not
 * submitted is not said, they are simply absent from `dishes`.
 */
export interface Dishes {
  readonly dishes: readonly Dish[];
  readonly expected: number;
}

export async function getDishes(contestId: string): Promise<Dishes> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/dishes`, 'GET');
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Dishes;
}

/** Submits (or revises) the participant's own dish; throws ApiError (e.g. a name is required). */
export async function submitDish(
  contestId: string,
  dish: { name: string; description?: string },
): Promise<Dish> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/dishes`, 'POST', dish);
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Dish;
}

/** The voter's ballot — what they may score, derived from the compiled constraint view. */
export interface Ballot {
  readonly contestId: string;
  readonly dishes: readonly { readonly dishId: string; readonly name: string }[];
  readonly categories: readonly { readonly id: string; readonly name: string }[];
  readonly range: { readonly min: number; readonly max: number };
  readonly uniquePerCategory: boolean;
}

/** One draft score the voter has saved. */
export interface Score {
  readonly dishId: string;
  readonly categoryId: string;
  readonly value: number;
}

/** Reads the voter's ballot; throws ApiError (401 when they haven't claimed a place). */
export async function getBallot(contestId: string): Promise<Ballot> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/ballot`, 'GET');
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Ballot;
}

/** Reads the scores the voter has saved so far. */
/** Whether the vote holding a participant's scores is still theirs to change. */
export type VoteStatus = 'draft' | 'sent';

export interface MyScores {
  readonly scores: readonly Score[];
  readonly status: VoteStatus;
}

/**
 * A participant's own scores, and whether their vote is still a draft.
 *
 * The status comes from the server rather than from anything the screen
 * remembers, so it survives a reload or a step back — which is what stops
 * someone who has already voted being shown an editable ballot they cannot use.
 */
export async function getMyScores(contestId: string): Promise<MyScores> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/scores`, 'GET');
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as MyScores;
}

/** Saves (or revises) one draft score; throws ApiError (e.g. out of range, or the vote is sent). */
export async function saveScore(contestId: string, score: Score): Promise<void> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/scores`, 'POST', score);
  if (!response.ok) throw await errorFrom(response);
}

/** Sends (locks) the vote; throws ApiError (e.g. incomplete, or already sent). */
export async function sendVote(contestId: string): Promise<void> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/send-vote`, 'POST');
  if (!response.ok) throw await errorFrom(response);
}

/** A dish's place on a reveal leaderboard. */
export interface Standing {
  readonly dishId: string;
  readonly name: string;
  readonly total: number;
}
export interface Winner {
  readonly dishId: string;
  readonly name: string;
}

/** The revealed results: winners and leaderboards, by dish name. */
export interface Reveal {
  readonly contestName: string;
  readonly overall: { readonly winners: readonly Winner[]; readonly standings: readonly Standing[] };
  readonly categories: readonly {
    readonly categoryId: string;
    readonly name: string;
    readonly winners: readonly Winner[];
    readonly standings: readonly Standing[];
  }[];
}

/**
 * Reads the revealed results, or `null` while the contest hasn't been revealed
 * yet (the app polls on that). Throws ApiError for other failures (401 when the
 * caller hasn't claimed a place).
 */
export async function getReveal(contestId: string): Promise<Reveal | null> {
  const response = await send(`/contests/${encodeURIComponent(contestId)}/reveal`, 'GET');
  if (response.status === 409) return null; // not revealed yet
  if (!response.ok) throw await errorFrom(response);
  return (await response.json()) as Reveal;
}

/** One participant, while the room waits: their name, and whether their vote is in. */
export interface TurnoutParticipant {
  readonly participantId: string;
  readonly displayName: string;
  readonly sent: boolean;
}

/** How the voting stands: how many are in, out of how many, and who is who. */
export interface Turnout {
  readonly votesIn: number;
  readonly votesExpected: number;
  readonly participants: readonly TurnoutParticipant[];
}

/**
 * Reads how the voting stands, or `null` where it cannot be read.
 *
 * Null rather than a throw, and deliberately: this is an addition to the
 * waiting screen, not the reason for it. A participant waiting for a reveal
 * must still be told they are waiting for a reveal if this fails — turning a
 * failed extra into an error screen would take away the thing that was already
 * working. Contest-deleted is the one exception, because that ends the wait.
 */
export async function getTurnout(contestId: string): Promise<Turnout | null> {
  try {
    const response = await send(`/contests/${encodeURIComponent(contestId)}/turnout`, 'GET');
    if (!response.ok) {
      if (response.status === 410) throw await errorFrom(response);
      return null;
    }
    return (await response.json()) as Turnout;
  } catch (caught) {
    if (isContestDeleted(caught)) throw caught;
    return null; // offline, blocked, malformed — the wait carries on regardless
  }
}
