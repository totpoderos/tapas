import { z, type ZodRawShape } from 'zod';
import type { ApiRequest } from './api-dispatcher.js';

/**
 * A tool the MCP server exposes (design.md §6). It carries the LLM-facing
 * definition (name, description, input shape) plus the protocol-level metadata
 * the adapter enforces — `destructive` triggers the confirmation flow, `scope`
 * is the authorization the API will require — and `toRequest`, the pure mapping
 * from validated arguments to the API request the adapter should make. The
 * mapping lives on each tool, so the dispatcher stays a single generic path
 * rather than a switch that grows with the catalog.
 *
 * `inputSchema` is a Zod raw shape: the SDK validates arguments against it and
 * derives the JSON schema advertised to the model, so there is no second,
 * hand-kept schema to drift.
 */
export interface McpTool {
  readonly name: string;
  readonly description: string;
  readonly destructive: boolean;
  readonly scope: 'host' | 'voter' | 'public';
  readonly inputSchema: ZodRawShape;
  toRequest(args: Record<string, unknown>): ApiRequest;
}

/**
 * `get_contest` — reads one of the host's own contests. Read-only and
 * host-scoped; the API enforces ownership, the adapter only forwards. The id
 * is URL-encoded so a value can never break out of the path.
 */
const getContest: McpTool = {
  name: 'get_contest',
  description: "Read one of the host's own contests by id and return its current state.",
  destructive: false,
  scope: 'host',
  inputSchema: { contestId: z.string().min(1).describe('The id of the contest to read.') },
  toRequest: (args) => ({
    method: 'GET',
    path: `/contests/${encodeURIComponent(String(args.contestId))}`,
  }),
};

/**
 * `list_my_contests` — lists everything the host owns (drafts still being
 * prepared and published contests alike), each with its id, name, and state, so
 * the host has an overview by name and never needs an internal id. Read-only and
 * host-scoped; the API returns only the host's own.
 *
 * Each entry also carries how the contest is going, so an assistant can answer
 * "how is the spring contest doing?" from the list instead of reading each
 * contest in turn. What a contest cannot have yet is absent rather than zero: a
 * draft has no join code and no progress, and saying it had none sent would read
 * as nobody having voted. The description says so, because an assistant that
 * mistakes one for the other tells the host something untrue.
 */
const listMyContests: McpTool = {
  name: 'list_my_contests',
  description:
    "List all of the host's own contests — both drafts still being prepared and published contests (live, closed, or revealed) — each with its id, name, and current state. Each also carries what it is judged on (attribution and how many scoring categories), its join code, and its progress (how many people have claimed a place, how many are still scoring, and how many have sent their vote). A contest still being prepared has no join code and no progress at all — that means voting has not started, which is NOT the same as nobody having voted yet.",
  destructive: false,
  scope: 'host',
  inputSchema: {},
  toRequest: () => ({ method: 'GET', path: '/contests' }),
};

/**
 * `find_contest` — resolves one of the host's contests by name (exact, but
 * case-insensitive), so a host can refer to a contest the way they say it rather
 * than by id. A name is not unique — a host may run "Tapas Night" more than once —
 * so this returns every match; the assistant asks the host which one when more
 * than one comes back. A name that matches nothing returns an empty list.
 * Read-only and host-scoped; the API searches only the host's own contests. The
 * name is URL-encoded so a value can never break out of the query.
 */
const findContest: McpTool = {
  name: 'find_contest',
  description:
    "Find one of the host's own contests by name (case-insensitive). Returns every contest with that exact name — usually one, but more if the host has reused a name — each with its id, name, and current state; an empty list means no contest has that name.",
  destructive: false,
  scope: 'host',
  inputSchema: {
    name: z.string().min(1).describe('The exact name of the contest to find (case-insensitive).'),
  },
  toRequest: (args) => ({
    method: 'GET',
    path: `/contests?name=${encodeURIComponent(String(args.name))}`,
  }),
};

/**
 * `get_contest_details` — reads what is inside one of the host's contests, found
 * by name: who is taking part and how it is scored. Works for a draft or a
 * published contest. Like `find_contest`, a name is not unique, so when several
 * share a name the candidates come back for the host to choose from. Read-only
 * and host-scoped; the name is URL-encoded so a value can never break out.
 */
const getContestDetails: McpTool = {
  name: 'get_contest_details',
  description:
    "Read the details of one of the host's own contests by name — its status, who is taking part, and its scoring categories. Works for a draft or a published contest. When several contests share the name, returns the candidates to choose from instead.",
  destructive: false,
  scope: 'host',
  inputSchema: {
    name: z.string().min(1).describe('The exact name of the contest whose details to read (case-insensitive).'),
  },
  toRequest: (args) => ({
    method: 'GET',
    path: `/contests/details?name=${encodeURIComponent(String(args.name))}`,
  }),
};

/**
 * `add_participant` — adds someone to one of the host's drafts, found by name.
 * For drafts only (a published contest's participants are settled). Reversible,
 * so not destructive. When several drafts share the name, the candidates come
 * back for the host to choose from.
 */
const addParticipant: McpTool = {
  name: 'add_participant',
  description:
    "Add a participant, by their display name, to one of the host's contest DRAFTS (found by the contest's name). Returns the draft's updated participant list, or — when several drafts share the name — the candidates to choose from.",
  destructive: false,
  scope: 'host',
  inputSchema: {
    contest: z.string().min(1).describe('The exact name of the draft to add to (case-insensitive).'),
    participant: z.string().min(1).describe('The display name of the participant to add.'),
  },
  toRequest: (args) => ({
    method: 'POST',
    path: '/drafts/participants',
    body: { contest: args.contest, participant: args.participant },
  }),
};

/**
 * `remove_participant` — removes someone from one of the host's drafts, found by
 * name. Destructive (removing a person), so the assistant confirms with the host
 * before it runs (design.md §6.1). The params ride the query so no body is needed.
 */
const removeParticipant: McpTool = {
  name: 'remove_participant',
  description:
    "Remove a participant, by their display name, from one of the host's contest DRAFTS (found by the contest's name). Returns the draft's updated participant list.",
  destructive: true,
  scope: 'host',
  inputSchema: {
    contest: z.string().min(1).describe('The exact name of the draft to remove from (case-insensitive).'),
    participant: z.string().min(1).describe('The display name of the participant to remove.'),
    confirmationToken: z
      .string()
      .optional()
      .describe('The confirmation token the server issued for this exact action.'),
  },
  toRequest: (args) => ({
    method: 'DELETE',
    path: `/drafts/participants?contest=${encodeURIComponent(String(args.contest))}&participant=${encodeURIComponent(String(args.participant))}`,
  }),
};

/** `get_draft` — reads one of the host's own contest drafts (still being prepared). */
const getDraft: McpTool = {
  name: 'get_draft',
  description: "Read one of the host's own contest drafts by id and return its current content.",
  destructive: false,
  scope: 'host',
  inputSchema: { draftId: z.string().min(1).describe('The id of the draft to read.') },
  toRequest: (args) => ({
    method: 'GET',
    path: `/drafts/${encodeURIComponent(String(args.draftId))}`,
  }),
};

/** `get_tally` — reads the live tally of the host's contest: how many have claimed, are scoring, have sent. */
const getTally: McpTool = {
  name: 'get_tally',
  description:
    "Read the live tally of one of the host's contests: how many participants have claimed a place, are still scoring, and have sent their votes.",
  destructive: false,
  scope: 'host',
  inputSchema: { contestId: z.string().min(1).describe('The id of the contest whose tally to read.') },
  toRequest: (args) => ({
    method: 'GET',
    path: `/contests/${encodeURIComponent(String(args.contestId))}/tally`,
  }),
};

/**
 * `close_contest` — forces one of the host's contests to close. Destructive
 * (irreversible), so the server requires a confirmation before it runs; the
 * optional `confirmationToken` is a protocol concern and is NOT forwarded to
 * the API (`toRequest` ignores it).
 */
const closeContest: McpTool = {
  name: 'close_contest',
  description:
    "Close one of the host's own contests now, so no more votes can be sent. This cannot be undone.",
  destructive: true,
  scope: 'host',
  inputSchema: {
    contestId: z.string().min(1).describe('The id of the contest to close.'),
    confirmationToken: z
      .string()
      .optional()
      .describe('The confirmation token the server issued for this exact action.'),
  },
  toRequest: (args) => ({
    method: 'POST',
    path: `/contests/${encodeURIComponent(String(args.contestId))}/close`,
  }),
};

// --- create_draft input shape ---------------------------------------------
// A draft's editable content (DraftContent): only `name` is required, the rest
// are filled in over time and fully validated by the API at publish. Defined
// here rather than imported from the domain so the adapter stays decoupled; the
// API remains the authoritative validator (two-phase, design.md §11B.3).
const scoringShape = z
  .object({
    categories: z.array(z.object({ id: z.string().min(1), name: z.string().min(1) }).strict()).min(1),
    range: z.union([
      z.object({ type: z.literal('fixed'), min: z.number(), max: z.number() }).strict(),
      z.object({ type: z.literal('auto') }).strict(),
    ]),
    uniquePerCategory: z.boolean(),
  })
  .strict();

const personShape = z
  .object({
    // Optional on purpose: an id is internal identity, not something a host
    // states, so a model asked for "participants: Juan and Paco" has no id to
    // give. The API assigns one to any participant that arrives without it (see
    // `withParticipantIds`). Supply an existing id to keep referring to the same
    // person — that is what pairings and `noScoreWith` point at.
    id: z.string().min(1).optional().describe('Existing participant id; omit for a new participant.'),
    displayName: z.string().min(1),
    partnerId: z.string().min(1).optional(),
    noScoreWith: z.array(z.string().min(1)).optional(),
  })
  .strict();

const whenShape = z.union([
  z.object({ when: z.enum(['all_sent', 'host_trigger']) }).strict(),
  z.object({ when: z.literal('scheduled'), at: z.string().min(1) }).strict(),
]);

/** `create_draft` — saves a new contest draft. Only the name is required. Writes via POST /drafts. */
const createDraft: McpTool = {
  name: 'create_draft',
  description:
    'Save a new contest draft for the host. Only a name is required; rule-space fields can be added now or later, and are fully checked when the contest is published.',
  destructive: false,
  scope: 'host',
  inputSchema: {
    name: z.string().min(1).describe('The contest name.'),
    attribution: z.enum(['per_person', 'per_couple']).optional(),
    antiBias: z.enum(['none', 'couples', 'arbitrary_pairs']).optional(),
    scoring: scoringShape.optional(),
    participants: z.array(personShape).optional(),
    closeRule: whenShape.optional(),
    revealStrategy: whenShape.optional(),
  },
  toRequest: (args) => ({ method: 'POST', path: '/drafts', body: args }),
};

/** `update_draft` — renames an existing draft (the only draft edit the API exposes today). */
const updateDraft: McpTool = {
  name: 'update_draft',
  description: "Rename one of the host's contest drafts.",
  destructive: false,
  scope: 'host',
  inputSchema: {
    draftId: z.string().min(1).describe('The id of the draft to rename.'),
    name: z.string().min(1).describe('The new name for the draft.'),
  },
  toRequest: (args) => ({
    method: 'PATCH',
    path: `/drafts/${encodeURIComponent(String(args.draftId))}`,
    body: { name: args.name },
  }),
};

/**
 * `publish_contest` — publishes a draft into a live contest. Destructive: a
 * live contest cannot be un-published, so the server requires a confirmation.
 */
const publishContest: McpTool = {
  name: 'publish_contest',
  description:
    'Publish one of the host\'s drafts into a live contest, running the rule compiler. This cannot be undone.',
  destructive: true,
  scope: 'host',
  inputSchema: {
    draftId: z.string().min(1).describe('The id of the draft to publish.'),
    confirmationToken: z
      .string()
      .optional()
      .describe('The confirmation token the server issued for this exact action.'),
  },
  toRequest: (args) => ({
    method: 'POST',
    path: `/drafts/${encodeURIComponent(String(args.draftId))}/publish`,
  }),
};

/**
 * `trigger_reveal` — reveals a closed contest, announcing the winners.
 * Destructive (it cannot be undone), so the server requires a confirmation.
 */
const triggerReveal: McpTool = {
  name: 'trigger_reveal',
  description:
    "Reveal one of the host's closed contests, announcing the winners. The contest must already be closed. This cannot be undone.",
  destructive: true,
  scope: 'host',
  inputSchema: {
    contestId: z.string().min(1).describe('The id of the closed contest to reveal.'),
    confirmationToken: z
      .string()
      .optional()
      .describe('The confirmation token the server issued for this exact action.'),
  },
  toRequest: (args) => ({
    method: 'POST',
    path: `/contests/${encodeURIComponent(String(args.contestId))}/reveal`,
  }),
};

/**
 * `delete_contest` — destroys one of the host's contests and everything in it.
 * The most destructive thing the surface offers and the only one with no undo,
 * so it is confirmation-gated like the rest.
 *
 * `confirmName` is not protocol ceremony: the API refuses (428) without the exact
 * contest name once anyone has claimed a place or cast a vote, so the assistant
 * must know and reproduce the name of the thing it is destroying. Because the
 * confirmation token is an HMAC over the arguments, a token issued for deleting
 * one contest cannot validate deleting another.
 */
const deleteContest: McpTool = {
  name: 'delete_contest',
  description:
    "Delete one of the host's own contests — a draft or a published one — together with its participants, dishes, scores and votes. Everything is destroyed and THIS CANNOT BE UNDONE. Once anyone has claimed a place or cast a vote, `confirmName` must be the contest's exact name.",
  destructive: true,
  scope: 'host',
  inputSchema: {
    contestId: z.string().min(1).describe('The id of the contest or draft to delete.'),
    confirmName: z
      .string()
      .optional()
      .describe("The contest's exact name. Required once anyone has taken part in it."),
    confirmationToken: z
      .string()
      .optional()
      .describe('The confirmation token the server issued for this exact action.'),
  },
  toRequest: (args) => {
    const path = `/contests/${encodeURIComponent(String(args.contestId))}`;
    const name = args.confirmName;
    return {
      method: 'DELETE',
      path: name === undefined ? path : `${path}?confirm=${encodeURIComponent(String(name))}`,
    };
  },
};

/** `get_results` — reads the final results of one of the host's revealed contests. */
const getResults: McpTool = {
  name: 'get_results',
  description:
    "Read the final results — category totals and winners — of one of the host's contests. The contest must already be revealed.",
  destructive: false,
  scope: 'host',
  inputSchema: {
    contestId: z.string().min(1).describe('The id of the revealed contest whose results to read.'),
  },
  toRequest: (args) => ({
    method: 'GET',
    path: `/contests/${encodeURIComponent(String(args.contestId))}/results`,
  }),
};

/** The tools the MCP server exposes. Grows one vertical slice at a time (design.md §6.1). */
export const TOOL_CATALOG: readonly McpTool[] = [
  getContest,
  listMyContests,
  findContest,
  getContestDetails,
  addParticipant,
  removeParticipant,
  getDraft,
  getTally,
  closeContest,
  createDraft,
  updateDraft,
  publishContest,
  triggerReveal,
  deleteContest,
  getResults,
];

/**
 * Validates a proposed tool call's arguments against that tool's own input
 * schema, returning the parsed arguments.
 *
 * The MCP server gets this for free — it hands `inputSchema` to the SDK, which
 * validates before the tool runs. The in-app assistant dispatches tool calls
 * itself, so without this the model's arguments reached the API unchecked: a
 * malformed call was stored rather than refused (that is how drafts came to hold
 * participants with no id). Both entry points now apply the same schema.
 *
 * Unknown keys are stripped rather than rejected: only fields the tool declares
 * are forwarded, so a model that volunteers an extra field is tidied up, not
 * refused — the same "read only known fields" discipline the draft guard uses.
 */
export function parseToolArguments(
  tool: McpTool,
  args: Record<string, unknown>,
): { readonly ok: true; readonly args: Record<string, unknown> } | { readonly ok: false; readonly message: string } {
  const parsed = z.object(tool.inputSchema).safeParse(args);
  if (parsed.success) return { ok: true, args: parsed.data as Record<string, unknown> };
  const detail = parsed.error.issues
    .map((issue) => `${issue.path.join('.') || '(root)'}: ${issue.message}`)
    .join('; ');
  return { ok: false, message: detail };
}
